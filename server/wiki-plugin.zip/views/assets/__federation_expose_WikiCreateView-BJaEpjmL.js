import{_ as t,__tla as a}from"./WikiCreateView.vue_vue_type_script_setup_true_lang-B8qAUOTd.js";let _=Promise.all([(()=>{try{return a}catch{}})()]).then(async()=>{});export{_ as __tla,t as default};
